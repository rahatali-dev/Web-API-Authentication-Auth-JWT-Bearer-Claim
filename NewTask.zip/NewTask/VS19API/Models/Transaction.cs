﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace VS19API.Models
{

    [DataContract]
    public class Transaction
    {
        [DataMember]
        public string TxnId { get; set; }

        [DataMember(IsRequired = false, EmitDefaultValue = false)]
        public DateTime TxnDate { get; set; }
        [DataMember]
        public Decimal TxnAmount { get; set; }
        [DataMember]
        public Decimal TxnTax { get; set; }
        [DataMember]
        public string TxnStatus { get; set; }
        [DataMember]
        public string Msisdn { get; set; }
        [DataMember]
        public string PackageName { get; set; }


        public List<Transaction> GetTransactionList(DateTime StartDate, DateTime EndDate, string PackageName, string Connectionstring)
        {

            List<Transaction> ListTransactions = new List<Transaction>();

          //  string Connectionstring = @"server=.\MSSQLSERVER1;database=TransactionDB;uid=sa;password=abc.1234;";
            SqlConnection cnn = new SqlConnection(Connectionstring);

            
            //  bool Is_valid = false;
            try
            {

                SqlCommand command = new SqlCommand();
                cnn.Open();
                command.Connection = cnn;
                SqlDataReader dataReader;

               // string sql = string.Format("");
                
                command.CommandText = "spGetData";
                command.Parameters.Add("@StartDate", System.Data.SqlDbType.DateTime);
                command.Parameters["@StartDate"].Value = StartDate;
                command.Parameters.Add("@EndDate", System.Data.SqlDbType.DateTime);
                command.Parameters["@EndDate"].Value = EndDate;

                command.Parameters.Add("@PackageName", System.Data.SqlDbType.VarChar);
                command.Parameters["@PackageName"].Value = PackageName;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    //          {
                    //              SELECT[TxnId]
                    //,[TxnDate]
                    //,[TxnAmount]
                    //,[TxnTax]
                    //,[TxnStatus]
                    //,[Msisdn] singlesle.Sale_Source = Convert.ToDecimal(dataReader["Sale_Source1"].ToString());

                    Transaction aTransaction = new Transaction();
                    aTransaction.TxnId = dataReader["TxnId"].ToString();
                    aTransaction.TxnDate = Convert.ToDateTime(dataReader["TxnDate"].ToString());
                    aTransaction.TxnAmount = Convert.ToDecimal(dataReader["TxnAmount"].ToString());
                    aTransaction.TxnTax = Convert.ToDecimal(dataReader["TxnTax"].ToString());
                    aTransaction.TxnStatus = dataReader["TxnStatus"].ToString();
                    aTransaction.Msisdn = dataReader["Msisdn"].ToString();
                    aTransaction.PackageName = dataReader["PackageName"].ToString();
                    ListTransactions.Add(aTransaction);
                }
                
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (cnn.State != ConnectionState.Closed)
                    cnn.Close();
            }


            return ListTransactions;

        }

        //1	TxnId YES String
        //2	TxnDate YES String
        //3	TxnAmount YES Double
        //4	TxnTax YES Double
        //5	TxnStatus YES String
        //6	Msisdn YES String
        //7	PackageName YES String


    }
}