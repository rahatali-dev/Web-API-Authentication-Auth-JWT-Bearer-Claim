﻿using VS19API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VS19API.Models
{
    public class APIOutput
    {
        public string result { get; set; }
        public List<Transaction> TransactionList { get; set; }
    }
}