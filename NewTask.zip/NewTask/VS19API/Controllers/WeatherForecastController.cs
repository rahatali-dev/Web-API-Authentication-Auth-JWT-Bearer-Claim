﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.AspNetCore.Mvc.Abstractions;


using RestSharp;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.AspNetCore.Http;
using System.Net;
using System.Net.Http;

namespace VS19API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

       
            [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            Microsoft.Extensions.Primitives.StringValues Autho = new Microsoft.Extensions.Primitives.StringValues();
                
           
           HttpContext.Request.Headers.TryGetValue("authorization", out Autho);
            string IncomingToken = "";
            if (Autho.Count == 1)  // Exactly One String Bearer
            {
                IncomingToken = Autho.ToArray()[0];
                IncomingToken = IncomingToken.Replace("Bearer", "").Trim();
            }
            else
            {
                //  return StatusCode(401, "My error message");
                //   Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                //  HttpContext.Response = new HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized);
                // return StatusCode((int)System.Net.HttpStatusCode.Unauthorized, "My error message");
                //return StatusCode(401, "My error message");
                //   HttpContext.Response = new Microsoft.AspNetCore.Authorization.AuthorizationFailure()

                


            }
           // bool ValidToken = ValidateCurrentToken(IncomingToken);
              //HttpContext.Request.Headers.TryGetValue("Authorization", out authorizationToken);

            //Microsoft.AspNetCore.Authentication.JwtBearer.
            //clm.
            //Response_Token respontoken = new Response_Token();
            //var client = new RestClient("https://dev-dd8cuohn.auth0.com/oauth/token");
            //var request = new RestRequest(Method.POST);
            //request.AddHeader("content-type", "application/json");
            //request.AddParameter("application/json", "{\"client_id\":\"zHU2TXwNkPbQuR2srHfFPfDDwtxXsZcB\",\"client_secret\":\"aPAA0RdWDEP8MX45FcgO-5v1stsM-dcLcTq3pO_VXt2gOz7qlmTgRndFZqN1wOhS\",\"audience\":\"http://localhost:2038/\",\"grant_type\":\"client_credentials\"}", ParameterType.RequestBody);
            //IRestResponse response = client.Execute(request);
            ////   (Response_Token)JsonConvert.DeserializeObject(response.Content.ToString());
            //respontoken = JsonConvert.DeserializeObject<Response_Token>(response.Content);

            //string AccessTokenTemp = GenerateToken(1);


            //string AccessTokenstr = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlFwMTNpOTZfVUJvN0NEakdyYy00dyJ9.eyJpc3MiOiJodHRwczovL2Rldi1kZDhjdW9obi5hdXRoMC5jb20vIiwic3ViIjoiekhVMlRYd05rUGJRdVIyc3JIZkZQZkREd3R4WHNaY0JAY2xpZW50cyIsImF1ZCI6Imh0dHA6Ly9sb2NhbGhvc3Q6MjAzOC8iLCJpYXQiOjE1OTAzNTc1ODgsImV4cCI6MTU5MDQ0Mzk4OCwiYXpwIjoiekhVMlRYd05rUGJRdVIyc3JIZkZQZkREd3R4WHNaY0IiLCJndHkiOiJjbGllbnQtY3JlZGVudGlhbHMifQ.iOIWKVM6HgHh3hR-KDCc4crcgIZ8ijxsC0ARMc-abHDfQFq4kvaoZMl_eqcP_8gYyDDWBiMDG-a4A6nrsHEklHssmVB4Ongc0wshLxDcc8rTiywpt-eNDjLPeLxgFGdfKFTzgWqvH_n1gXfS8KMrfKIsJ5_-qkQE8zDAJSK4B9zAHVOX7cgF5-bVI1yxVWYDSaEGROAF0IJQetAcNnoy79NrZz4m10Z1_WmixDF4O8Ct27VO4xSpNuA54CtYTSlXJHDiPRTTTQ5bG-jygHKIDJnPDGEaw7Bo82db7rYMvsYNAqQGFzVlWkyrKDbp4vHstvOZANWd2b-pTi-e3y53Jw";

            var clientAPI = new RestClient("http://localhost:2038/glossary");
            var requestAPI = new RestRequest(Method.GET);

           string AccessTokenstr = "";
            requestAPI.AddHeader("content-type", "application/json");
            
           //requestAPI.AddParameter("application/json","");
            // requestAPI.AddHeader("Authorization", "Bearer "  + respontoken.access_token);
            requestAPI.AddHeader("authorization", string.Format("Bearer {0}", AccessTokenstr));
            

            //clientAPI.AddDefaultHeader()

            //request.AddParameter("application/json", "{\"client_id\":\"hZwgPXxa1ekJdSOP3qYKXFHilOZDvq0R\",\"client_secret\":\"LaD9HJCu4A9Z2FEbZw0naGUnguGoe4u7GmlZsYHLB1z5lulSZAcrMJOwi4nUx0WJ\",\"audience\":\"https://webapi.com\",\"grant_type\":\"client_credentials\"}", ParameterType.RequestBody);

            IRestResponse responseAPI = clientAPI.Execute(requestAPI);


            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}
