﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.Extensions.Configuration;


using RestSharp;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.AspNetCore.Http;
using System.Net;
using System.Net.Http;
using VS19API.Models;
using System.IO;
using System.Dynamic;

namespace VS19API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private IConfiguration configfile;

        public ReportController (IConfiguration config)
        {
            configfile = config;
        }

        [HttpPost]
        public APIOutput GetTransactions(ReportInput RptInput)
        {
           // string JSONstr = "";
            APIOutput ResultOutput = new APIOutput();
            ResultOutput.result = "";
          //  dynamic dynresult = new ExpandoObject();

            List<Transaction> Transactions = new List<Transaction>();
            Transaction DBA = new Transaction();

           //string TokenIssued = GenerateToken(3);
            //resultobj.abc = "";
            try
            {
                // Read Token Header
                Microsoft.Extensions.Primitives.StringValues Autho = new Microsoft.Extensions.Primitives.StringValues();

                HttpContext.Request.Headers.TryGetValue("authorization", out Autho); // Authorization Header is must
                string IncomingToken = "";
                if (Autho.Count == 1)  // Exactly One String Bearer
                {
                    IncomingToken = Autho.ToArray()[0];
                    IncomingToken = IncomingToken.Replace("Bearer", "").Trim();
                    bool IsTokentValid = ValidateCurrentToken(IncomingToken);
                    if(!IsTokentValid) // Invalid Token
                    {
                        ResultOutput.result = "Unauthorized request (401) Invalid Token";
                        //dynresult.List = Transactions;
                    }
                    else // Valid Request
                    {
                        ResultOutput.result = "";
                        string Connectionstr = configfile.GetSection("ConnectionStrings").GetSection("conn").Value.ToString();
                        ResultOutput.TransactionList = DBA.GetTransactionList(RptInput.StartDate, RptInput.EndDate, RptInput.PackageName, Connectionstr);
                        //dynresult.List = Transactions;
                    }

                }
                else
                {
                    ResultOutput.result = "Unauthorized request (401)";
                 //   dynresult.List = Transactions;


                }

                
                
            }
            catch (Exception ex)
            {
                ResultOutput.result = ex.ToString();
            }
            finally
            {
              //  dynresult.List = Transactions;
            }

            return ResultOutput;
            

        }

        public string GenerateToken(int userId)
        {
            #region "temp"
            //var mySecret = "asdv234234^&%&^%&^hjsdfb2%%%";
            //var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

            //var myIssuer = "http://mysite.com";
            //var myAudience = "http://myaudience.com";
            #endregion
            var mySecret = configfile.GetSection("Auth0").GetSection("clientid").Value;//"asdv234234^&%&^%&^hjsdfb2%%%"; // Secret Key
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret)); //new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

            var myIssuer = configfile.GetSection("Auth0").GetSection("Domain").Value;//"http://mysite.com"; // Issuer
            var myAudience = configfile.GetSection("Auth0").GetSection("Audience").Value;//"http://myaudience.com"; // Audience
            #region "tempregion"
            //var mySecret = configfile.GetSection("Auth0").GetSection("clientid").Value;//"asdv234234^&%&^%&^hjsdfb2%%%"; // Secret Key
            //var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(configfile.GetSection("Auth0").GetSection("clientsecret").Value)); //new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

            //var myIssuer = configfile.GetSection("Auth0").GetSection("Domain").Value;//"http://mysite.com"; // Issuer
            //var myAudience = configfile.GetSection("Auth0").GetSection("Audience").Value;//"http://myaudience.com"; // Audience
            #endregion
            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                Issuer = myIssuer,
                Audience = myAudience,
                SigningCredentials = new SigningCredentials(mySecurityKey, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
        public bool ValidateCurrentToken(string token)
        {
            var mySecret = configfile.GetSection("Auth0").GetSection("clientid").Value;//"asdv234234^&%&^%&^hjsdfb2%%%"; // Secret Key
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret)); //new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

            var myIssuer = configfile.GetSection("Auth0").GetSection("Domain").Value;//"http://mysite.com"; // Issuer
            var myAudience = configfile.GetSection("Auth0").GetSection("Audience").Value;//"http://myaudience.com"; // Audience
            #region "Temp"
            //var mySecret = "asdv234234^&%&^%&^hjsdfb2%%%";
            //var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

            //var myIssuer = "http://mysite.com";
            //var myAudience = "http://myaudience.com";
            #endregion


            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = myIssuer,
                    ValidAudience = myAudience,
                    IssuerSigningKey = mySecurityKey
                }, out SecurityToken validatedToken);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

    }
}
