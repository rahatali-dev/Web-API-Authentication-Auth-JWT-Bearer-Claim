﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web;
using System.Net;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;
using System.Net.Http.Headers;

namespace ServerAPI
{
    public static class Misc
    {

        public static object DeserializeFromStream(MemoryStream stream)
        {
            IFormatter formatter = new BinaryFormatter();
            stream.Seek(0, SeekOrigin.Begin);
            object o = formatter.Deserialize(stream);
            return o;
        }

        public static string WebAPIGet(string BaseURL, string MethodName)
        {
            string JsonOutput = "";
            try
            {
               // HttpClient client = new HttpClient();
                var credentials = new NetworkCredential(ConfigurationManager.AppSettings["Source1User"].ToString(), ConfigurationManager.AppSettings["Source1Password"].ToString());
                var handler = new HttpClientHandler { Credentials = credentials };
                using (var client = new HttpClient(handler))
                {
                    client.BaseAddress = new Uri(BaseURL);
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                    
                    var responseTask = client.GetAsync(MethodName);
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                      //  var readTask = result.Content.ReadAsStreamAsync<Student>();
                        using (var content =   result.Content.ReadAsStreamAsync())
                                    {
                                      StreamReader reader = new StreamReader(content.Result);
                                       JsonOutput = reader.ReadToEnd();
                                     
                                      //JsonConvert.PopulateObject(JsonString, SaleList);
                                    }
                    }
                }
                
            }
            catch(Exception ex)
            { 
            }
            finally
            {

            }
            return JsonOutput;
        }
        public static string WebAPIGet1(string BaseURL, string MethodName)
        {
            string JsonOutput = "";
            try
            {
                // HttpClient client = new HttpClient();
               // var credentials = new NetworkCredential(ConfigurationManager.AppSettings["Source1User"].ToString(), ConfigurationManager.AppSettings["Source1Password"].ToString());
               // var handler = new HttpClientHandler { Credentials = credentials };
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(BaseURL);
                    //client.DefaultRequestHeaders.Add("Accept", "application/json");
                    client.DefaultRequestHeaders.Add("Bearer", "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlFwMTNpOTZfVUJvN0NEakdyYy00dyJ9.eyJpc3MiOiJodHRwczovL2Rldi1kZDhjdW9obi5hdXRoMC5jb20vIiwic3ViIjoiekhVMlRYd05rUGJRdVIyc3JIZkZQZkREd3R4WHNaY0JAY2xpZW50cyIsImF1ZCI6Imh0dHA6Ly9sb2NhbGhvc3Q6MjAzOC8iLCJpYXQiOjE1OTAzNTc1ODgsImV4cCI6MTU5MDQ0Mzk4OCwiYXpwIjoiekhVMlRYd05rUGJRdVIyc3JIZkZQZkREd3R4WHNaY0IiLCJndHkiOiJjbGllbnQtY3JlZGVudGlhbHMifQ.iOIWKVM6HgHh3hR-KDCc4crcgIZ8ijxsC0ARMc-abHDfQFq4kvaoZMl_eqcP_8gYyDDWBiMDG-a4A6nrsHEklHssmVB4Ongc0wshLxDcc8rTiywpt-eNDjLPeLxgFGdfKFTzgWqvH_n1gXfS8KMrfKIsJ5_-qkQE8zDAJSK4B9zAHVOX7cgF5-bVI1yxVWYDSaEGROAF0IJQetAcNnoy79NrZz4m10Z1_WmixDF4O8Ct27VO4xSpNuA54CtYTSlXJHDiPRTTTQ5bG-jygHKIDJnPDGEaw7Bo82db7rYMvsYNAqQGFzVlWkyrKDbp4vHstvOZANWd2b-pTi-e3y53Jw");
                    var responseTask = client.GetAsync(MethodName);
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        //  var readTask = result.Content.ReadAsStreamAsync<Student>();
                        using (var content = result.Content.ReadAsStreamAsync())
                        {
                            StreamReader reader = new StreamReader(content.Result);
                            JsonOutput = reader.ReadToEnd();

                            //JsonConvert.PopulateObject(JsonString, SaleList);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
            }
            finally
            {

            }
            return JsonOutput;
        }
        public static string WebAPIPost(string BaseURL, string MethodName, string Poststring)
        {
            string JsonOutput = "";
            try
            {
                string AccessTokenstr = ConfigurationManager.AppSettings["AccessToken"].ToString();
                // HttpClient client = new HttpClient();
                //  var credentials = new NetworkCredential(ConfigurationManager.AppSettings["Source1User"].ToString(), ConfigurationManager.AppSettings["Source1Password"].ToString());
                // var handler = new HttpClientHandler { Credentials = credentials };
                using (var client = new HttpClient())
                {
                    var httpContent = new StringContent(Poststring, Encoding.UTF8, "application/json");

                    client.BaseAddress = new Uri(BaseURL);
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                    client.DefaultRequestHeaders.Add("authorization", string.Format("Bearer {0}", AccessTokenstr));

                    var responseTask = client.PostAsync(MethodName, httpContent);
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        //  var readTask = result.Content.ReadAsStreamAsync<Student>();
                        using (var content = result.Content.ReadAsStreamAsync())
                        {
                            StreamReader reader = new StreamReader(content.Result);
                            JsonOutput = reader.ReadToEnd();

                            //JsonConvert.PopulateObject(JsonString, SaleList);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
            }
            finally
            {

            }
            return JsonOutput;
        }
    }
}