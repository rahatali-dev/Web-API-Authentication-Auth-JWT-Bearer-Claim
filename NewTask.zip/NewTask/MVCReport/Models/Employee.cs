﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShowReport.Models
{
    public class Employee
    {
        public string ID { get; set; }
        public string Name { get; set; }
    }

    public class ReportOption
    {
        public string OptionID { get; set; }
        public string OptionName { get; set; }
    }
}