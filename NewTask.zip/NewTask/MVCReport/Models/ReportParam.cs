﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCReport.Models
{
    public class ReportParam
    {
        [Required]
        public string PackageName { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
}