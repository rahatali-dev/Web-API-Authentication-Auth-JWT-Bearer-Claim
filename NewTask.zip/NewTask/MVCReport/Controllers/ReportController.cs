﻿using MVCReport.Models;
using ShowReport.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using Microsoft.Reporting.WebForms;
//using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using System.Web.UI.WebControls;
using System.Reflection.Emit;
using ServerAPI;
using System.Configuration;

namespace MVCReport.Controllers
{
    public class ReportController : Controller
    {
        // GET: Report
        public ActionResult Index()
        {
            //ReportInput rptOption = new ReportInput();
            List<SelectListItem> OptionLookup = new List<SelectListItem>();

            OptionLookup.Add(new SelectListItem { Text = "All", Value = "All" });
            OptionLookup.Add(new SelectListItem { Text = "OCM1", Value = "OCM1" });
            OptionLookup.Add(new SelectListItem { Text = "OCM6", Value = "OCM6" });
            OptionLookup.Add(new SelectListItem { Text = "OCM10", Value = "OCM10" });

            // rptOption.PackageName = "";
            //rptOption.AllPackages = OptionLookup;
            ViewBag.OptionLookup = new SelectList(OptionLookup, "Value", "Text");

            return View();
        }
        [HttpPost]
        public ActionResult Index(ReportInput param)
        {
            ViewBag.paramresult = "";
            try
            {
                List<SelectListItem> OptionLookup = new List<SelectListItem>();

                OptionLookup.Add(new SelectListItem { Text = "All", Value = "All" });
                OptionLookup.Add(new SelectListItem { Text = "OCM1", Value = "OCM1" });
                OptionLookup.Add(new SelectListItem { Text = "OCM6", Value = "OCM6" });
                OptionLookup.Add(new SelectListItem { Text = "OCM10", Value = "OCM10" });

                // rptOption.PackageName = "";
                //rptOption.AllPackages = OptionLookup;
                ViewBag.OptionLookup = new SelectList(OptionLookup, "Value", "Text");
                if (!ModelState.IsValid)
                {


                    return View();
                }
                else // Valid Model Get All Records now
                {
                    DateTime StartDate;
                    DateTime EndDate;
                    string PackageName = "";
                    // ReportInput.Date_From = DateTime.ParseExact(DateTimeFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    // ReportInput.Date_To = DateTime.ParseExact(DateTimeTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                    string strViewBag = "";

                    if(!Validate_Data(param.StartDate, param.EndDate, out strViewBag))
                    {
                        ViewBag.paramresult = strViewBag;
                        return View();
                    }
                        

                    StartDate = DateTime.ParseExact(param.StartDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    EndDate = DateTime.ParseExact(param.EndDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);

                    PackageName = param.PackageName.Trim();
                    // New Model
                    Transaction DBModel = new Transaction();
                    List<Transaction> ListTransaction = new List<Transaction>();
                    string BaseURL = ConfigurationManager.AppSettings["SourceAPI"].ToString();
                    string InputJson = Newtonsoft.Json.JsonConvert.SerializeObject(param);
                    string Result = Misc.WebAPIPost(BaseURL, "Report", InputJson);
                    // ListTransaction = DBModel.GetTransactionList(StartDate, EndDate, PackageName);
                    APIOutput APIOut = new APIOutput();
                    Newtonsoft.Json.JsonConvert.PopulateObject(Result, APIOut);
                    ListTransaction = APIOut.TransactionList;
                    if (ListTransaction.Count > 0 )
                    {
                        ReportViewer rptview = new ReportViewer();
                        rptview.LocalReport.ReportPath = Server.MapPath("~/Report1.rdlc");
                        rptview.ProcessingMode = ProcessingMode.Local;
                        rptview.SizeToReportContent = true;
                        rptview.Width = Unit.Percentage(900);
                        rptview.Height = Unit.Percentage(1200);
                        ReportDataSource datasource = new ReportDataSource("DataSet1", ListTransaction);
                        rptview.LocalReport.DataSources.Add(datasource);
                        ViewBag.ReportViewer = rptview;

                        return View("ViewReport");
                    }
                    else
                    {
                        ViewBag.paramresult = "No data found";
                        return View();
                    }
                    
                }
            }
            catch (Exception ex)
            {
                // Error Part
                ViewBag.paramresult = ex.Message.ToString(); ;
                return View();
            }
        }
        private bool Validate_Data(string DateFrom, string DateTo, out string resultstr)
        {
            DateTime dtFrom, dtTo;
            bool result = false;
            resultstr = "";
            try
            {

                try
                {
                    //ReportInput.Date_To = DateTime.ParseExact(DateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    dtFrom = DateTime.ParseExact(DateFrom, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                }
                catch (Exception ex)
                {
                    resultstr = "Invalid Start Date";
                    return false;
                }
                try
                {
                    //DateTime.TryParse(DateTo, out DateCheckTo);
                    dtTo = DateTime.ParseExact(DateTo, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                }
                catch (Exception ex)
                {
                    resultstr = "Invalid End Date ";
                    return false;
                }

                // Range Validation

                if (dtFrom.Date > DateTime.Now.Date || dtTo.Date > DateTime.Now.Date)
                {
                    resultstr = "Sorry future dates are not allowed";
                    return false;
                }
                if (dtFrom.Date > dtTo.Date.Date)
                {
                    resultstr = "Invalid date range";
                    return false;
                }

                result = true;




            }
            catch (Exception ex)
            {

            }

            return result;
        }

        public ActionResult ViewReport(List<Transaction> Transaction)
        {
            ReportViewer rptview = new ReportViewer();
            rptview.LocalReport.ReportPath = Server.MapPath("~/Report1.rdlc");
            rptview.ProcessingMode = ProcessingMode.Local;
            rptview.SizeToReportContent = true;
            rptview.Width = Unit.Percentage(900);
            rptview.Height = Unit.Percentage(1200);
            ReportDataSource datasource = new ReportDataSource("DataSet1", Transaction);
            rptview.LocalReport.DataSources.Add(datasource);
            ViewBag.ReportViewer = rptview;

            return View("ViewReport");
        }
    }

    }
